package com.example.myfitness.entities

data class Exercises (var exercise: String)