package com.example.myfitness.entities

data class PlanPreferences(
    val preference: String,
    val experience: String,
    val days: Int
)