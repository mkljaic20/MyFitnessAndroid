package com.example.myfitness.entities

data class Plan(
    var day: String,
    var exercise: List<Exercises>
)